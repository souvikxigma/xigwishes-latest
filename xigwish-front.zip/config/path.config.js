module.exports = {
    ADMINPATH: "http://localhost:9128/admin",
    BASEPATH: "http://localhost:9128",

    // ADMINPATH: "https://testxigwish.xigwishes.com/admin",
    // BASEPATH: "https://testxigwish.xigwishes.com",
};
